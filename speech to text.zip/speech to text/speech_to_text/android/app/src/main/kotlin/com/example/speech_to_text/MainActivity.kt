package com.example.speech_to_text

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
